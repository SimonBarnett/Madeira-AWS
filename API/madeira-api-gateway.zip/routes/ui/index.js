// ====================== routes/ui/index.js ======================
// UI Routes Sub-Router
// Creates one pool per request and passes { pool, sandbox } to all handlers

// IMPORTANT: Do NOT close the pool here. It is passed from the main orchestrator.

const { logger, getDbConnection } = require('/opt/nodejs/helpers');

const cmsProvidersHandler = require('./cmsProviders');
const apiKeysHandler = require('./apiKeys');
const metricsHandler = require('./metrics');
const chartDataHandler = require('./chartData');
const merchantPartsHandler = require('./merchantParts');
const categoryHandler = require('./category');
const resetHandler = require('./reset');
const deleteHandler = require('./delete');
const addRoleHandler = require('./addRole');

module.exports = async (event) => {
    // Normalize path for both direct calls and /{proxy+} under /ui
    let path = event.path || '/';

    // Remove /ui prefix if present (for requests coming through the proxy)
    if (path.startsWith('/ui')) {
        path = path.replace(/^\/ui/, '');
    }

    // Ensure path always starts with a forward slash
    if (!path.startsWith('/')) {
        path = '/' + path;
    }

    // Update event.path so downstream handlers see the normalized path
    event.path = path;

    const method = event.httpMethod;
    const decoded = event.decoded;

    logger.debug('UI Router received request', {
        originalPath: event.path,
        normalizedPath: path,
        method
    });

    const pool = await getDbConnection();
    const sandbox = process.env.SANDBOX === 'true';

    try {
        if (path.startsWith('/cms-providers')) {
            return await cmsProvidersHandler(event, { pool, sandbox });

        } else if (path.startsWith('/api-keys')) {
            return await apiKeysHandler(event, { pool, sandbox });

        } else if (path === '/metrics' && method === 'GET') {
            return await metricsHandler(event, { pool, sandbox });

        } else if (path === '/chart-data' && method === 'GET') {
            return await chartDataHandler(event, { pool, sandbox });

        } else if (path === '/merchant-parts' && method === 'GET') {
            return await merchantPartsHandler(event, { pool, sandbox });

        } else if (path === '/category' && (method === 'GET' || method === 'POST')) {
            const body = event.body ? JSON.parse(event.body) : {};
            const result = await categoryHandler(decoded.user_id, body, method, { pool, sandbox });
            return { statusCode: 200, body: result };

        } else if (path === '/category/reset' && method === 'POST') {
            const result = await resetHandler(decoded.user_id, { pool, sandbox });
            return { statusCode: 200, body: result };

        } else if (path.startsWith('/delete')) {
            return await deleteHandler(event, { pool, sandbox });

        } else if (path === '/add-role' && method === 'POST') {
            return await addRoleHandler(event, { pool, sandbox });

        } else {
            logger.warn('UI route not found', { path, method });
            return {
                statusCode: 404,
                body: { message: 'UI route not found' }
            };
        }
    } catch (error) {
        logger.error('Error in UI router', { path, error: error.message });
        return {
            statusCode: 500,
            body: { message: error.message || 'Internal Server Error' }
        };
    }
    // Pool is intentionally NOT closed here (passed from main orchestrator)
};